package cuiconnect02;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DeleteEventFeedback {
    private JFrame frame;
    private String currentUserRole;
    private String currentUserEmail;
    private String currentUserPassword;
    private String currentSocietyName;

    // Constructor accepting user details, allowing null values
    public DeleteEventFeedback(String userDetails) {
        // If userDetails is null, set defaults
        this.currentUserRole = (userDetails != null) ? userDetails : "Default Role";
        this.currentUserEmail = (userDetails != null) ? userDetails : "default@example.com";
        this.currentUserPassword = (userDetails != null) ? userDetails : "defaultPassword";
        this.currentSocietyName = (userDetails != null) ? userDetails : "Default Society";

        // Create the main frame
        frame = new JFrame("Delete Event Feedback");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(350, 600);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(10, 25, 50));

        JLabel titleLabel = new JLabel("Delete Event Feedback");
        titleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);  // Align title to left
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(titleLabel);

        // Create form fields with left-aligned labels
        JLabel eventNameLabel = new JLabel("Enter event name:");
        eventNameLabel.setForeground(Color.WHITE);
        eventNameLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JTextField eventNameField = new JTextField();
        eventNameField.setMaximumSize(new Dimension(600, 30));  // Set text field width to double
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(eventNameLabel);
        panel.add(eventNameField);

        JLabel emailLabel = new JLabel("Enter your Email:");
        emailLabel.setForeground(Color.WHITE);
        emailLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JTextField emailField = new JTextField();
        emailField.setMaximumSize(new Dimension(600, 30));  // Set text field width to double
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(emailLabel);
        panel.add(emailField);

        JLabel userRoleLabel = new JLabel("Enter your Role (Admin/Other):");
        userRoleLabel.setForeground(Color.WHITE);
        userRoleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JTextField userRoleField = new JTextField();
        userRoleField.setMaximumSize(new Dimension(600, 30));  // Set text field width to double
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(userRoleLabel);
        panel.add(userRoleField);

        JLabel feedbackIndexLabel = new JLabel("Enter Feedback Index:");
        feedbackIndexLabel.setForeground(Color.WHITE);
        feedbackIndexLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JTextField feedbackIndexField = new JTextField();
        feedbackIndexField.setMaximumSize(new Dimension(600, 30));  // Set text field width to double
        panel.add(Box.createRigidArea(new Dimension(0, 10)));
        panel.add(feedbackIndexLabel);
        panel.add(feedbackIndexField);

        // Create Enter button
        JButton enterButton = new JButton("Enter");
        enterButton.setAlignmentX(Component.CENTER_ALIGNMENT);  // Align button to center
        enterButton.setBackground(Color.WHITE);
        enterButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String eventName = eventNameField.getText();
                String email = emailField.getText();
                String userRole = userRoleField.getText();
                String feedbackIndexText = feedbackIndexField.getText();

                try {
                    int feedbackIndex = Integer.parseInt(feedbackIndexText); // Convert to integer
                    EventFeedback eventFeedback = new EventFeedback();
                    eventFeedback.deleteFeedback(eventName, email, userRole, feedbackIndex);
                    JOptionPane.showMessageDialog(frame, "Feedback deleted successfully!");
                } catch (CustomException ex) {
                    JOptionPane.showMessageDialog(frame, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid feedback index.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // Create Back button
        JButton backButton = new JButton("Back");
        backButton.setAlignmentX(Component.CENTER_ALIGNMENT);  // Align button to center
        backButton.setBackground(Color.WHITE);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.dispose();  // Close the current DeleteEventFeedback screen
                // Navigate to FeedbackScreen, passing necessary user details
                new FeedbackScreen(currentUserRole, currentUserEmail, currentUserPassword, currentSocietyName).display();
            }
        });

        // Set up panel borders and spacing
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.add(Box.createRigidArea(new Dimension(0, 30)));
        panel.add(enterButton);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(backButton);

        frame.add(panel);
        frame.setVisible(true);
    }

    // Method to display the frame
    public void display() {
        frame.setVisible(true);
    }
}
