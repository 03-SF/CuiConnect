package cuiconnect02;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Post implements Serializable {
    private static final long serialVersionUID = 1L;

    private static int postIdCounter = 1; // Counter for unique post IDs
    private int id;
    private String content;
    private String role; // Role of the user (Admin, Student, SocietyPresident)
    private String email; // Email of the user who created the post
    private int likes; // Number of likes for the post
    private List<Comment> comments; // List of comments on the post

    // Constructor
    public Post(String content, String role, String email) {
        this.id = postIdCounter++;
        this.content = content;
        this.role = role;
        this.email = email;
        this.likes = 0;
        this.comments = new ArrayList<>();
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getContent() {
        return content;
    }

    public String getRole() {
        return role;
    }

    public String getEmail() {
        return email;
    }

    public int getLikes() {
        return likes;
    }

    public List<Comment> getComments() {
        return comments;
    }

    // Like a post
    public void likePost() {
        this.likes++;
    }

    // Initialize post ID counter from posts.dat file
    public static void initializePostIdCounter() {
        List<Object> objectList = FileHandler.readFromFile("posts.dat");
        int highestId = 0;

        for (Object obj : objectList) {
            if (obj instanceof Post) {
                Post post = (Post) obj;
                if (post.getId() > highestId) {
                    highestId = post.getId();
                }
            }
        }

        postIdCounter = highestId + 1; // Set to the next available ID
    }

    // Save post ID counter to file
    private static void savePostIdCounter() {
        FileHandler.writeToFile("postIdCounter.dat", postIdCounter);
    }

    // Add a comment to a post
    public void addComment(String commentContent, String commenterEmail) {
        if (commentContent == null || commentContent.trim().isEmpty()) {
            throw new IllegalArgumentException("Comment content cannot be null or empty.");
        }
        Comment newComment = new Comment(commentContent, commenterEmail);
        comments.add(newComment);
    }

    // Get comments for a post as a list of strings
    public List<String> getCommentDetails() {
        List<String> commentDetails = new ArrayList<>();
        for (Comment comment : comments) {
            commentDetails.add(comment.toString());
        }
        return commentDetails;
    }

    // Delete a comment from a post
    public void deleteComment(int commentIndex, boolean isAdmin, String userEmail) throws CustomException {
        if (commentIndex < 0 || commentIndex >= comments.size()) {
            throw new CustomException("Invalid comment index.");
        }

        Comment commentToDelete = comments.get(commentIndex);
        if (isAdmin || commentToDelete.getEmail().equalsIgnoreCase(userEmail)) {
            comments.remove(commentIndex);
        } else {
            throw new CustomException("You do not have permission to delete this comment.");
        }
    }

    // Static method to delete comment from a post by post ID and comment index
    public static void deleteCommentFromPost(int postId, int commentIndex, String userEmail, boolean isAdmin) throws CustomException {
        List<Post> posts = FileHandler.readFromFile("posts.dat");

        Post postToDeleteComment = posts.stream()
                .filter(post -> post.getId() == postId)
                .findFirst()
                .orElseThrow(() -> new CustomException("Post with the given ID not found."));

        postToDeleteComment.deleteComment(commentIndex, isAdmin, userEmail);

        // Save updated posts back to file
        FileHandler.clearFile("posts.dat");
        for (Post post : posts) {
            FileHandler.writeToFile("posts.dat", post);
        }
    }

    // Static method to add a new post
    public static Post addPost(String content, String role, String email) {
        if (content == null || content.trim().isEmpty()) {
            throw new IllegalArgumentException("Post content cannot be null or empty.");
        }

        Post newPost = new Post(content, role, email);
        FileHandler.writeToFile("posts.dat", newPost);
        return newPost;
    }

    // Static method to retrieve posts for a specific email
    public static List<Post> getPostsByEmail(String emailToView) throws UserNotFoundException {
        List<Post> posts = FileHandler.readFromFile("posts.dat");
        List<Post> userPosts = new ArrayList<>();

        for (Post post : posts) {
            if (post.getEmail().equalsIgnoreCase(emailToView)) {
                userPosts.add(post);
            }
        }

        if (userPosts.isEmpty()) {
            throw new UserNotFoundException("No posts found for the provided email.");
        }

        return userPosts;
    }

    // Static method to delete a post
    public static void deletePost(int postId, String email, String role, boolean isAdmin) throws CustomException {
        List<Post> posts = FileHandler.readFromFile("posts.dat");
        Post postToDelete = posts.stream()
                .filter(post -> post.getId() == postId && (isAdmin || post.getEmail().equalsIgnoreCase(email)))
                .findFirst()
                .orElseThrow(() -> new CustomException("Post not found or no permission to delete."));

        posts.remove(postToDelete);

        // Rewrite posts back to file
        FileHandler.clearFile("posts.dat");
        for (Post post : posts) {
            FileHandler.writeToFile("posts.dat", post);
        }
    }

    // Static method to like a post by ID
    public static void likePostById(int postId) throws CustomException {
        List<Post> posts = FileHandler.readFromFile("posts.dat");
        Post postToLike = posts.stream()
                .filter(post -> post.getId() == postId)
                .findFirst()
                .orElseThrow(() -> new CustomException("Post with ID " + postId + " not found."));

        postToLike.likePost();

        // Save updated posts back to file
        FileHandler.clearFile("posts.dat");
        for (Post post : posts) {
            FileHandler.writeToFile("posts.dat", post);
        }
    }

    // Static method to add a comment to a post
    public static void addCommentToPost(int postId, String commentContent, String commenterEmail) throws CustomException {
        List<Post> posts = FileHandler.readFromFile("posts.dat");
        Post postToCommentOn = posts.stream()
                .filter(post -> post.getId() == postId)
                .findFirst()
                .orElseThrow(() -> new CustomException("Post with ID " + postId + " not found."));

        postToCommentOn.addComment(commentContent, commenterEmail);

        // Save updated posts back to file
        FileHandler.clearFile("posts.dat");
        for (Post post : posts) {
            FileHandler.writeToFile("posts.dat", post);
        }
    }

    // Static method to retrieve all posts
    public static List<Post> getAllPosts() throws CustomException {
        List<Post> posts = FileHandler.readFromFile("posts.dat");
        if (posts.isEmpty()) {
            throw new CustomException("No posts available.");
        }
        return posts;
    }
}
