package cuiconnect02; 

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PostScreen {
    private JFrame frame;

    // Constructor accepts user role and other parameters
    public PostScreen(JFrame adminScreen, String currentUserRole, String currentUserEmail, String currentUserPassword, String currentSocietyName) {
        // Create the main frame
        frame = new JFrame("Post");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(350, 600);
        frame.setLayout(new BorderLayout());
        frame.getContentPane().setBackground(new Color(10, 25, 74)); // Entire background blue

        // Create components
        JPanel headingPanel = createHeadingPanel();
        JPanel buttonPanel = createButtonPanel();
        JPanel backPanel = createBackButtonPanel(adminScreen, currentUserRole, currentUserEmail, currentUserPassword, currentSocietyName);

        // Add components to frame
        frame.add(headingPanel, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.CENTER);
        frame.add(backPanel, BorderLayout.SOUTH);
    }

    // Create the heading panel
    private JPanel createHeadingPanel() {
        JPanel headingPanel = new JPanel();
        headingPanel.setBackground(new Color(10, 25, 74));
        headingPanel.setLayout(new BorderLayout());
        headingPanel.setBorder(BorderFactory.createEmptyBorder(40, 20, 10, 20)); // Add space above heading

        JLabel headingLabel = new JLabel("Post", SwingConstants.CENTER);
        headingLabel.setForeground(Color.WHITE);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 20));
        headingPanel.add(headingLabel, BorderLayout.CENTER);

        return headingPanel;
    }

    // Create the button panel with all action buttons
    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(8, 1, 10, 10));
        buttonPanel.setBackground(new Color(10, 25, 74)); // Blue background
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Add space around buttons

        // Create buttons with > icon
        String[] buttonLabels = {
                "Create a Post",
                "Like a Post",
                "Add Comment",
                "View Comment",
                "Delete Comment",
                "Delete Post",
                "View All Posts"
        };

        for (String label : buttonLabels) {
            RoundedButton button = new RoundedButton(label + " >", 15);
            button.addActionListener(new ButtonClickListener(label));
            buttonPanel.add(button);
        }

        return buttonPanel;
    }

    // Create the back button panel with user role navigation
    private JPanel createBackButtonPanel(JFrame adminScreen, String currentUserRole, String currentUserEmail, String currentUserPassword, String currentSocietyName) {
        RoundedButton backButton = new RoundedButton("Back", 15) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 50, 50); // Larger rounded corners
                super.paintComponent(g2);
                g2.dispose();
            }

            @Override
            protected void paintBorder(Graphics g) {
                // Do not draw any border
            }
        };

        backButton.setFont(new Font("Arial", Font.PLAIN, 14));
        backButton.setPreferredSize(new Dimension(100, 40));
        backButton.setBackground(new Color(10, 25, 74));
        backButton.setForeground(Color.WHITE);

        // Action to navigate based on user role
        backButton.addActionListener(e -> {
        frame.dispose(); // Close the current screen (PostScreen)
        System.out.println("Navigating back with role: " + currentUserRole);

        // Navigate to appropriate screen based on user role
        switch (currentUserRole.trim().toLowerCase()) {
            case "admin":
                new AdminScreen(currentUserRole, currentUserEmail, currentUserPassword, currentSocietyName);
                break;
            case "student":
                Student student = new Student(currentUserEmail, currentUserPassword);
                new StudentScreen(student);
                break;
            case "societypresident":
                new PresidentScreen(currentUserRole, currentUserEmail, currentUserPassword, currentSocietyName);
                break;
            default:
                JOptionPane.showMessageDialog(null, "Unknown user role: " + currentUserRole);
                break;
        }
    });


        JPanel backPanel = new JPanel();
        backPanel.setBackground(new Color(10, 25, 74));
        backPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        backPanel.setLayout(new BorderLayout());
        backPanel.add(backButton, BorderLayout.CENTER);

        return backPanel;
    }

    // Display the frame
    public void display() {
        frame.setVisible(true);
    }

    // ActionListener for buttons
    static class ButtonClickListener implements ActionListener {
        private String buttonName;

        public ButtonClickListener(String buttonName) {
            this.buttonName = buttonName;
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            switch (buttonName) {
                case "Create a Post":
                    new CreatePostScreen(null); // You can pass the appropriate parent frame
                    break;
                case "Like a Post":
                    new LikePostScreen(null);
                    break;
                case "Add Comment":
                    new AddCommentScreen(null);
                    break;
                case "View Comment":
                    new ViewCommentScreen(null);
                    break;
                case "Delete Comment": 
                    String title = "Post Title";
                    String content = "This is the content of the post.";
                    String authorEmail = "author@example.com";

                    // Create the Post object with required arguments
                    Post myPost = new Post(title, content, authorEmail);

                    // Set the Post instance for the DeleteCommentScreen
                    DeleteCommentScreen.setPost(myPost);
                    new DeleteCommentScreen(null);
                    break;
                case "Delete Post":
                    new DeletePostScreen(null);
                    break;
                case "View All Posts":
                    new ViewPostScreen(null);
                    break;
                default:
                    System.out.println("Unknown button clicked");
                    break;
            }
        }
    }
}
